<?php $__env->startSection('title', $product->__('name')); ?>
<?php $__env->startSection('content'); ?>
    <script>
        $(document).ready(function(){
            PopUpHide();
        });
        function PopUpShow(){
            $("#popup1").show();
        }
        function PopUpHide(){
            $("#popup1").hide();
        }

    </script>

    <h1><?php echo e($product->__('name')); ?></h1>
    <h2><?php echo e($product->category->__('name')); ?></h2>
    <p>Цена: <b><?php echo e($product->price); ?> ₸</b></p>

    <div class="imagehover">
        <img src="<?php echo e(Storage::url($product->image)); ?>" alt="Avatar" class="image" style="width:100%">
        <div class="middle">
            <button onclick="PopUpShow()" class="btn btn-success" role="button"><?php echo app('translator')->get('main.3d_model'); ?></button>
        </div>
    </div>

    <p><?php echo e($product->__('description')); ?></p>
    <form action="<?php echo e(route('basket-add', $product)); ?>" method="POST">
        <button type="submit" class="btn btn-success" role="button"><?php echo app('translator')->get('main.add_cart'); ?></button>
        <?php echo csrf_field(); ?>
    </form>

    <div class="b-popup" id="popup1">
        <div class="b-popup-content">

            <div class="sketchfab-embed-wrapper">
                <iframe id="3d" title="A 3D model" width="640" height="480" src="<?php echo e($product->model_3d); ?>" frameborder="0" allow="autoplay; fullscreen; vr" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
            </div>

            <button onclick="PopUpHide()" class="btn btn-success" role="button"><?php echo app('translator')->get('main.close_3d_model'); ?></button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/product.blade.php ENDPATH**/ ?>