<?php $__env->startSection('title', 'Оформить заказ'); ?>

<?php $__env->startSection('content'); ?>
        <h1><?php echo app('translator')->get('main.confirm_order'); ?>:</h1>
        <div class="container">
            <div class="row justify-content-center">
                <p><?php echo app('translator')->get('main.total'); ?>: <b><?php echo e($order->getFullPrice()); ?> ₸</b></p>
                <form action="<?php echo e(route('basket-confirm')); ?>" method="POST">
                    <div>
                        <p><?php echo app('translator')->get('main.your_data'); ?>:</p>

                        <div class="container">
                            <div class="form-group">
                                <label for="name" class="control-label col-lg-offset-3 col-lg-2"><?php echo app('translator')->get('main.name'); ?>: </label>
                                <div class="col-lg-4">
                                    <input type="text" name="name" id="name" value="" class="form-control">
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="form-group">
                                <label for="phone" class="control-label col-lg-offset-3 col-lg-2"><?php echo app('translator')->get('main.phone_number'); ?>: </label>
                                <div class="col-lg-4">
                                    <input type="text" name="phone" id="phone" value="" class="form-control">
                                </div>
                            </div>
                            <br>
                            <br>
                        </div>
                        <br>
                        <?php echo csrf_field(); ?>
                        <br>
                        <input type="submit" class="btn btn-success" value="<?php echo app('translator')->get('main.confirm_order'); ?>">
                    </div>
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/order.blade.php ENDPATH**/ ?>