<?php if(isset($product)): ?>
    <?php $__env->startSection('title', 'Редактировать товар' . $product->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Добавить товар'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(isset($product)): ?>
            <h1>Редактировать Товар
                <bold><?php echo e($product->name); ?></bold>
            </h1>
        <?php else: ?>
            <h1>Добавить Товар</h1>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data"
              <?php if(isset($product)): ?>
              action="<?php echo e(route('products.update', $product)); ?>"
              <?php else: ?>
              action="<?php echo e(route('products.store')); ?>"
            <?php endif; ?>
        >
            <div>
                <?php if(isset($product)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Код: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="text" class="form-control" name="code" id="code"
                               value="<?php echo e(old('code', isset($product) ? $product->code : null)); ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name" class="col-sm-2 col-form-label">Название: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="text" class="form-control" name="name" id="name"
                               value="<?php if(isset($product)): ?><?php echo e($product->name); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name_en" class="col-sm-2 col-form-label">Название en: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'name_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="text" class="form-control" name="name_en" id="name_en"
                               value="<?php if(isset($product)): ?><?php echo e($product->name_en); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="category_id" class="col-sm-2 col-form-label">Категория: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'category_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <select name="category_id" id="category_id" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                        <?php if(isset($product)): ?>
                                        <?php if($product->category_id == $category->id): ?>
                                        selected
                                    <?php endif; ?>
                                    <?php endif; ?>
                                ><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="description" class="col-sm-2 col-form-label">Описание: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <textarea name="description" id="description" cols="72"
                                  rows="7"><?php if(isset($product)): ?><?php echo e($product->description); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="description_en" class="col-sm-2 col-form-label">Описание en: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <textarea name="description_en" id="description_en" cols="72"
                                  rows="7"><?php if(isset($product)): ?><?php echo e($product->description_en); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="image" class="col-sm-2 col-form-label">Картинка: </label>
                    <div class="col-sm-10">
                        <label class="btn btn-default btn-file">
                            Загрузить <input type="file" style="display: none;" name="image" id="image">
                        </label>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="price" class="col-sm-2 col-form-label">Цена: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'price'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="text" class="form-control" name="price" id="price"
                               value="<?php if(isset($product)): ?><?php echo e($product->price); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="model_3d" class="col-sm-2 col-form-label">Ссылка на 3д модель: </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="model_3d" id="model_3d"
                               value="<?php if(isset($product)): ?><?php echo e($product->model_3d); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <?php $__currentLoopData = [
                 'hit' => 'Хит',
                 'new' => 'Новинка',
                 'rec' => 'Рекомендуемые',
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check row">
                        <label for="code" class="col-sm-2 col-form-label"><?php echo e($title); ?>: </label>
                        <div class="col-sm-6">
                            <input type="checkbox" class="form-check" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>"
                                   <?php if(isset($product) && $product->$field ===1): ?>
                                   checked="checked"
                                <?php endif; ?>
                            >
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/auth/products/form.blade.php ENDPATH**/ ?>