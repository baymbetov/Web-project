<?php $__env->startSection('title', 'Продукт ' . $product->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h1><?php echo e($product->name); ?></h1>
        <table class="table">
            <tbody>
            <tr>
                <th>
                    Поле
                </th>
                <th>
                    Значение
                </th>
            </tr>
            <tr>
                <td>ID</td>
                <td><?php echo e($product->id); ?></td>
            </tr>
            <tr>
                <td>Код</td>
                <td><?php echo e($product->code); ?></td>
            </tr>
            <tr>
                <td>Название</td>
                <td><?php echo e($product->name); ?></td>
            </tr>
            <tr>
                <td>Название en</td>
                <td><?php echo e($product->name_en); ?></td>
            </tr>
            <tr>
                <td>Описание</td>
                <td><?php echo e($product->description); ?></td>
            </tr>
            <tr>
                <td>Описание en</td>
                <td><?php echo e($product->description_en); ?></td>
            </tr>
            <tr>
                <td>Картинка</td>
                <td><img src="<?php echo e(Storage::url($product->image)); ?>" height="240px"></td>
            </tr>
            <tr>
                <td>Категория</td>
                <td><?php echo e($product->category->name); ?></td>
            </tr>
            <tr>
                <td>Лейблы</td>
                <td>
                    <?php if($product->isNew()): ?>
                        <span class="badge badge-success">Новинка</span>
                    <?php endif; ?>
                    <?php if($product->isRec()): ?>
                        <span class="badge badge-warning">Рекомендуем</span>
                    <?php endif; ?>
                    <?php if($product->isHit()): ?>
                        <span class="badge badge-danger">Хит продаж!</span>
                    <?php endif; ?>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/auth/products/show.blade.php ENDPATH**/ ?>