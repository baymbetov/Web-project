<?php $__env->startSection('title', 'Заказ ' . $order->id); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-4">
        <div class="container">
            <div class="justify-content-center">
                <div class="panel">
                    <h1>Заказ №<?php echo e($order->id); ?></h1>
                    <p>Заказчик: <b><?php echo e($order->name); ?></b></p>
                    <p>Номер телефона: <b><?php echo e($order->phone); ?></b></p>
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th>Название</th>
                            <th>Кол-во</th>
                            <th>Цена</th>
                            <th>Стоимость</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('product', $product)); ?>">
                                        <img height="56px"
                                             src="<?php echo e(Storage::url($product->image)); ?>">
                                        <?php echo e($product->__('name')); ?>

                                    </a>
                                </td>
                                <td><span class="badge">1</span></td>
                                <td><?php echo e($product->price); ?></td>
                                <td><?php echo e($product->getPriceForCount()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="3">Общая стоимость:</td>
                            <td><?php echo e($order->getFullPrice()); ?> тг.</td>
                        </tr>
                        </tbody>
                    </table>
                    <br>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/auth/orders/show.blade.php ENDPATH**/ ?>