<?php if(isset($category)): ?>
    <?php $__env->startSection('title', 'Редактировать категорию ' . $category->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать категорию'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(isset($category)): ?>
            <h1>Редактировать Категорию
                <bold><?php echo e($category->name); ?></bold>
            </h1>
        <?php else: ?>
            <h1>Добавить Категорию</h1>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data"
              <?php if(isset($category)): ?>
              action="<?php echo e(route('categories.update', $category)); ?>"
              <?php else: ?>
              action="<?php echo e(route('categories.store')); ?>"
            <?php endif; ?>
        >
            <div>
                <?php if(isset($category)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Код: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'code'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="text" class="form-control" name="code" id="code"
                               value="<?php echo e(old('code', isset($category) ? $category->code : null)); ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name" class="col-sm-2 col-form-label">Название: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="text" class="form-control" name="name" id="name"
                               value="<?php if(isset($category)): ?><?php echo e($category->name); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name_en" class="col-sm-2 col-form-label">Название en: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'name_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <input type="text" class="form-control" name="name_en" id="name_en"
                               value="<?php if(isset($category)): ?><?php echo e($category->name_en); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="description" class="col-sm-2 col-form-label">Описание: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <textarea name="description" id="description" cols="72"
                                  rows="7"><?php if(isset($category)): ?><?php echo e($category->description); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="description_en" class="col-sm-2 col-form-label">Описание en: </label>
                    <div class="col-sm-6">
                        <?php echo $__env->make('auth.layouts.error', ['fieldName' => 'description_en'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <textarea name="description_en" id="description_en" cols="72"
                                  rows="7"><?php if(isset($category)): ?><?php echo e($category->description_en); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="image" class="col-sm-2 col-form-label">Картинка: </label>
                    <div class="col-sm-10">
                        <label class="btn btn-default btn-file">
                            Загрузить <input type="file" name="image" id="image" style="display: none">
                        </label>
                    </div>
                </div>
                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/auth/categories/form.blade.php ENDPATH**/ ?>