<section class="top-header">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-xs-12 col-sm-4">
                <div class="contact-number">
                    <i class="tf-ion-ios-telephone"></i>
                    <span>+7 707 141 5141</span><br/>
                    <i class="tf-ion-ios-telephone"></i>
                    <span>+7 747 983 2705</span><br/>
                    <i class="tf-ion-ios-telephone"></i>
                    <span>+7 708 358 5452</span>
                </div>
            </div>
            <div class="col-md-4 col-xs-12 col-sm-4">
                <!-- Site Logo -->
                <div class="logo text-center">
                    <a href="<?php echo e(route('index')); ?>">
                        <h1 class="shadow">3D Store</h1>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-xs-12 col-sm-4">
                <!-- Cart -->
                <ul class="top-menu text-right list-inline">
                    <li class="dropdown cart-nav dropdown-slide">

                        <?php echo app('translator')->get('main.current_lang'); ?>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('locale', 'ru')); ?>">ru</a></li>
                            <li><a href="<?php echo e(route('locale', 'en')); ?>">en</a></li>
                        </ul>
                    </li>
                    <li class="dropdown cart-nav dropdown-slide">
                        <a href="<?php echo e(route('basket')); ?>"><i class="tf-ion-android-cart"></i><?php echo app('translator')->get('main.cart'); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section><!-- End Top Header Bar -->


<!-- Main Menu Section -->
<section class="menu">
    <nav class="navbar navigation" id="mainnav" style="background-color: white">
        <!-- Navbar Links -->
        <div id="navbar" class="navbar-collapse collapse text-center">
            <ul class="nav navbar-nav">

                <!-- Home -->
                <li <?php echo Route::currentRouteNamed('index') ? 'class="active"' : '' ?>>
                    <a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->get('main.all_products'); ?></a>
                </li><!-- / Home -->
                <li <?php echo Route::currentRouteNamed('categories') ? 'class="active"' : '' ?> class="dropdown dropdown-slide">
                    <a href="<?php echo e(route('categories')); ?>" class="dropdown-toggle"><?php echo app('translator')->get('main.categories'); ?> <span
                            class="tf-ion-ios-arrow-down"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('category', 'mobiles')); ?>"><?php echo app('translator')->get('main.smartphones'); ?></a></li>
                        <li><a href="<?php echo e(route('category', 'portable')); ?>"><?php echo app('translator')->get('main.portables'); ?></a></li>
                        <li><a href="<?php echo e(route('category', 'appliances')); ?>"><?php echo app('translator')->get('main.appliances'); ?></a></li>
                    </ul>
                </li>

                <!-- Elements -->
                <?php if(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>"><?php echo app('translator')->get('main.login'); ?></a></li>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                    <li><a href="<?php echo e(route('orders')); ?>"><?php echo app('translator')->get('main.admin_panel'); ?></a></li>
                <?php else: ?>
                    <li><a href="<?php echo e(route('person.orders.index')); ?>"><?php echo app('translator')->get('main.my_orders'); ?></a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo e(route('get-logout')); ?>"><?php echo app('translator')->get('main.logout'); ?></a></li>
            <?php endif; ?>
            <!-- / Elements -->
            </ul><!-- / .nav .navbar-nav -->

        </div><!--/.navbar-collapse -->
    </nav>
</section>
<?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>