<div class="col-sm-6 col-md-4">
    <div class="thumbnail">
        <div class="labels">
            <?php if($product->isNew()): ?>
                <span class="badge badge-success"><?php echo app('translator')->get('main.properties.new'); ?></span>
            <?php endif; ?>
            <?php if($product->isRec()): ?>
                <span class="badge badge-warning"><?php echo app('translator')->get('main.properties.rec'); ?></span>
            <?php endif; ?>
            <?php if($product->isHit()): ?>
                <span class="badge badge-danger"><?php echo app('translator')->get('main.hit_sales'); ?></span>
            <?php endif; ?>
        </div>
        <img src="<?php echo e(Storage::url($product->image)); ?>" alt="<?php echo e($product->__('name')); ?>">
        <div class="caption">
            <h3><?php echo e($product->__('name')); ?></h3>
            <p><?php echo e($product->price); ?> ₸</p>
            <p>
            <form action="<?php echo e(route('basket-add', $product)); ?>" method="POST">
                <button type="submit" class="btn btn-primary" role="button"><?php echo app('translator')->get('main.add_cart'); ?></button>
                <a href="<?php echo e(route('product', [$product->category->code, $product->code])); ?>"
                   class="btn btn-default"
                   role="button"><?php echo app('translator')->get('main.details'); ?></a>
                <?php echo csrf_field(); ?>
            </form>
            </p>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\appLaravel\resources\views/layouts/card.blade.php ENDPATH**/ ?>